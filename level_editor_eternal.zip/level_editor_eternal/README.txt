Q - delete
E - wall
AWDS - corners
SPACE - spikes
1 - turret
2 - rocket launcher
3 - laser
4 - robot

SHIFT+CONTROL+N - new
CONTROL+S - save